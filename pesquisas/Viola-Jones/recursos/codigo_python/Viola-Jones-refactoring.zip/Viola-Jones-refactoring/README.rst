Viola-Jones
-----------

Python implementation of the face detection algorithm by Paul Viola and Michael J. Jones
